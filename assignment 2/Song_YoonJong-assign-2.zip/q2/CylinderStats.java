package q2;

import java.text.DecimalFormat;
import java.util.Scanner;
/**
 * <p>An application, called CylinderStats, that reads the radius and height of 
 * a cylinder and prints its surface area & volume. Use the following formulas. 
 * Print the output to four decimal places. In the formulas, r represents the 
 * radius and h the height. </p>
 *
 * @author Song, Yoonjong
 * @version 1.0
 */
public class CylinderStats {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        //declare constant variables
        final int two = 2;
        final double pi = 3.14;
        //declare variables
        double radious;
        double height;
        double surfaceArea;
        double volume;
        
        //read height, radius via the prompt
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter radius : ");
        radious = scan.nextDouble();
        System.out.println("Please enter height : ");
        height = scan.nextDouble();
        
        //set the number to four decimal places
        DecimalFormat fmt = new DecimalFormat("0.0000");
        
        //compute surface area and volume of cylinder 
        surfaceArea = two * pi * radious * (radious + height);
        volume = pi * radious * radious * height;

        //print the surface area and volume of cylinder with four decimal places
        System.out.println("============================================");
        System.out.println("Surface area of cylinder is " 
                              + fmt.format(surfaceArea));
        System.out.println("The Volume of cylinder is " + fmt.format(volume));
        System.out.println("============================================");
        System.out.println("Question two was called and ran sucessfully.");
        scan.close();
    }

}
