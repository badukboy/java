package q4;

/**
 * <p>Class Box, contains instance data: width, depth and height
 * of the box. Also boolean variable full as instance data.
 * Box constructor to accept and initialize the width, depth
 * and height of the box. Each newly created box is empty.
 * The constructor should initialize full to false.
 * Getter and setter methods for all instance data.
 * toString method returns a one-line description of
 * the box.</p>
 *
 * @author Song Yoonjong
 * @version 1.0
 */
public class Box {
    /**
     *  declare height to private double.
     */
    private double height;
    
    /**
     *  declare width to private double.
     */
    private double width;
    
    /**
     *  declare depth to private double.
     */
    private double depth;

    /**
     *  declare boolean to private full.
     */
    private boolean full;
    
    /**
     *  make box constructor. 
     */
    Box() {
        height = 0;
        width = 0;
        depth = 0;
        full = false;
    }
    
    /**
     * Constructor: accept and initialize the height, width and 
     * depth of the box.
     *      
     * @param boxHeight height
     * @param boxWidth width
     * @param boxDepth depth
     * @param boxFull full
     */
    Box(double boxHeight, double boxWidth, double boxDepth, boolean boxFull) {
        height = boxHeight;
        width = boxWidth;
        depth = boxDepth;
        full = boxFull;
    }

    /**
     * set height of the box.
     * @param h height
     */
    public final void setHeight(double h) {
        height = h;
    }

    /**
     * get height of the box.
     * @return height
     */
    public final double getHeight() {
        return height;
    }

    /**
     * set width of the box.
     * @param w width
     */
    public final void setWidth(double w) {
        width = w;
    }

    /**
     * get width of the box.
     * 
     * @return width
     */
    public final double getWidth() {
        return width;
    }

    /**
     * To set depth of the box.
     * 
     * @param d depth
     */
    public final void setDepth(double d) {
        depth = d;
    }

    /**
     * get depth of the box.
     * 
     * @return depth
     */
    public final double getDepth() {
        return depth;
    }

    /**
     * set box is full or not.
     * 
     * @param f full
     */
    public final void setFull(boolean f) {
        full = f;
    }

    /**
     * box is full or not.
     * 
     * @return full
     */
    public final boolean getFull() {
        return full;
    }

    @Override
    /**
     * a one-line description of the box.
     */
    public final String toString() {
        return ("The box: " + height + ", " + width + ", " + depth 
                 + ", " + full);
    }

}
