package q4;

/**
 * <p>A Driver class, BoxText, instantiates and updates
 * two Box objects. BoxText should call each Box method
 * at least once and print information of the boxes.</p>
 *
 * @author Song Yoonjong
 * @version 1.0
 */
public class BoxTest {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {

        //instantiate two box objects.
        Box b1 = new Box(1, 2, Integer.parseInt("3"), true);
        Box b2 = new Box(1, 2, Integer.parseInt("5"), false);

        //call first box method at least once and print information of of box
        System.out.println("Box1 :");
        System.out.println("====================================== ");
        System.out.println("Height: " + b1.getHeight());
        System.out.println("Width: " + b1.getWidth());
        System.out.println("Depth: " + b1.getDepth());
        System.out.println("If Box is full - true, "
                            + " otherwise - false: "
                            + b1.getFull());
        System.out.println("Description of Box: " + b1.toString());
        System.out.println(" ");

        //call second box method at least once and print information of of box
        System.out.println("Box2 :");
        System.out.println("====================================== ");
        System.out.println("Height: " + b2.getHeight());
        System.out.println("Width: " + b2.getWidth());
        System.out.println("Depth: " + b2.getDepth());
        System.out.println("If Box is full - true,"
                            + " otherwise - false: "
                            + b2.getFull());
        System.out.println("Description of Box: " + b2.toString());
        System.out.println("====================================== ");
        System.out.println("Question four was called and ran sucessfully.");
    }

}
