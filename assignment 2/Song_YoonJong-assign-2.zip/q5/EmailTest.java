package q5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * <p>An application EmailTest implements a prototype user interface 
 * for composing an email message.</p>
 *
 * @author Song Yoonjong
 * @version 1.0
 */
public class EmailTest extends JFrame {
    
    /**
     *  indicate version of this panel.
     */
    private static final long serialVersionUID = 1L;

    /**
     *  for To:.
     */
    private JTextField field1;
    /**
     *  for CC.
     */
    private JTextField field2;
    /**
     *  for BCC.
     */
    private JTextField field3;
    /**
     *  for Subject.
     */
    private JTextField field4;

    /**
     *  for Message.
     */
    private JTextArea textArea;
    
    /**
     * to create panel for setting all the contents.
     *
     * @author Song Yoonjong
     *
     */
    public class BodyOfPanel extends JPanel {
        /**
         *  indicate version of this panel.
         */
        private static final long serialVersionUID = 1L;

        /**
         * set labels, contents of the text field,
         * text area, and button.
         */
        public BodyOfPanel() {

            JLabel label1 = new JLabel("     To:              ");
            JLabel label2 = new JLabel("     CC:              ");
            JLabel label3 = new JLabel("    BCC:              ");
            JLabel label4 = new JLabel("Subject:              ");
            JLabel label5 = new JLabel("Message:              ");


            field1 = new JTextField(Integer.parseInt("20"));
            field2 = new JTextField(Integer.parseInt("20"));
            field3 = new JTextField(Integer.parseInt("20"));
            field4 = new JTextField(Integer.parseInt("20"));

            textArea = new JTextArea(Integer.parseInt("10"), 
                                     Integer.parseInt("20"));

            JButton button = new JButton("Send");

            button.addActionListener(new ButtonListener());
            
            add(label1);
            add(field1);
            add(label2);
            add(field2);
            add(label3);
            add(field3);
            add(label4);
            add(field4);
            add(label5);

            add(textArea);
            add(button);
        }
    }
    
    
    /**
     * the user click "send" button, the program
     * print the contents of all fields.
     * @author Song Yoonjong
     *
     */
    private class ButtonListener implements ActionListener {
        @Override     
        public void actionPerformed(ActionEvent e) {
            System.out.println("     To: " + field1.getText());
            System.out.println("     Cc: " + field2.getText());
            System.out.println("    Bcc: " + field3.getText());
            System.out.println("Subject: " + field4.getText());
            System.out.println("Message: " + textArea.getText());
        }
    }

    /**
     * <p>The default constructor which sets the title of this app, sets the
     * default close operation to exit, creates a new content pane and finally
     * sets size and sets the visibility of this frame to true (show).</p>
     *
     */
    public EmailTest() {
        super("Poor English");
        BodyOfPanel bp = new BodyOfPanel();
        getContentPane().add(bp);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(Integer.parseInt("400"), Integer.parseInt("500"));
        setVisible(true);
    }

    /**
     * <p>The main method.</p>
     * @param args this is the main method
     */
    public static void main(String[] args) {
        new EmailTest();
    }
}
    
