package q3;

/**
 * <p>This is where you put your description about what this class does. You
 * don't have to write an essay but you should describe exactly what it does.
 * Describing it will help you to understand the programming problem better.</p>
 *
 * @author Song, Yoonjong
 * @version 1.0
 */
public class Cylinder {
    /** 
     * to assign 2 to variable two.
     */     
    private final int two = 2;
    /** 
     * to assign 3.14 to variable pi.
     */  
    private final double pi = 3.14;
    /** 
     * to declare radius to private double.
     */  
    private double radius;
    /**
     * to declare variable height to private height.
     */
    private double height;
    
    /**
     *  to set up cylinder in the constructor.
     */
    Cylinder() {
        radius = 0;
        height = 0;
    }
    
    /**
     * to make a constructor for Cylinder.
     * define its newRadius and newHeight
     * 
     * @param newRadius radius
     * @param newHeight height
     */
    Cylinder(double newRadius, double newHeight) {
        radius = newRadius;
        height = newHeight;
    } 
    
    //set up the radius of cylinder with newRadius
    /**
     * to set up the radius of cylinder.
     * 
     * @param newRadius radius
     */
    public void setRadious(double newRadius) {
        radius = newRadius;
    }
   
    /**
     * to get the radius of cylinder. 
     *    
     * @return radius
     */
    public double getRadius() {
        return radius;
    }

    /**
     * to set up the height of cylinder. 
     * 
     * @param newHeight height
     */
    public void setHeight(double newHeight) {
        height = newHeight;
    }
   
    /**
     * get the radius of cylinder.
     * 
     * @return height
     */
    public double getHeight() {
        return height;
    }
    
    /**
     * calculate the surfaceArea of cylinder. 
     * 
     * @return surfaceArea
     */
    public final double surfaceArea() {
        return (two * pi * radius * (radius + height));        
    }

    /**
     * calculate the volume of cylinder and return the volume. 
     *  
     * @return surfaceArea
     */
    public final double volume() {
        return (pi * radius * radius * height);        
    }
    
    @Override
    //a toString method that returns a one-line description of the cylinder
    public String toString() {
        return ("Radius: " + radius + ", " + "Heigh: " + height + ", "
                 + "SurfaceArea: " + surfaceArea() + ", "
                 + "" + "Volume : " + volume());
    }    
}
    

