package q3;

/**
 * <p>a driver class, called MultiCylinder, that instantiates and updates 
 * two Cylinder objects, printing their radius and height before and 
 * after modification, and prints the final volume and surface area 
 * of each cylinder.</p>
 *
 * @author Song Yoonjong
 * @version 1.0
 */
public class MultiCylinder {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        /**
         * to assign 2 to variable three.
         */
        final int two = 2;
        
        /**
         * to assign 4 to variable four.
         */
        final int four = 4;
        
        /**
         * to assign 3 to variable three.
         */
        final int three = 3;
        
        /**
         * to assign 5 to variable five.
         */
        final int five = 5;
        
        /**
         * to instantiate two objects.
         */
        Cylinder cylinder1 = new Cylinder(two, four);
        Cylinder cylinder2 = new Cylinder(three, five);
        
        /**
         * to print radius and height before
         * to print surface area and volume before
         */
        System.out.println("First cylinder before: " + cylinder1.toString());
        System.out.println("Second cylinder before: " + cylinder2.toString());
        System.out.println("=================================================");
        
        /**
         * to assign cylinder1 to cylinder2.
         */
        cylinder1 = cylinder2;

        /**
         * to print radius and height after.
         * to print surface area and volume after.
         */
        System.out.println("First cylinder after: " + cylinder1.toString());
        System.out.println("Second cylinder after: " + cylinder2.toString());
        System.out.println("=================================================");
        System.out.println("Question three was called and ran sucessfully.");
    }

};
