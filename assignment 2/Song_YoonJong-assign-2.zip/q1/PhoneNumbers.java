package q1;

import java.util.Random;
import java.text.DecimalFormat;
/**
 * <p>an application, called PhoneNumbers, that creates and 
 * prints a random phone number of the form XXX-XXX-XXXX. Include 
 * the dashes in the output. The phone number has some constraints. 
 * Do not let the first three digits contain an 8 or 9 (but do not 
 * be more restrictive than that), and ensure that the second set 
 * of three digit is not greater than 635. Note that any of the 
 * digits can be zero</p>
 *
 * @author Song, Yoonjong
 * @version 1.0
 */
public class PhoneNumbers {
   /**
    * <p>This is the main method (entry point) that gets called by the JVM.</p>
    *
    * @param args command line arguments.
    */    
    public static void main(String[] args) {
            
        //declare variables for phone number
        int num1;
        int num2;
        int num3;
        int setTwo;
        int num7;
        int num8;
        int num9;
        int num10;  
        String setOne;
        String setThree;
        
        //to get new random number
        Random generator = new Random();
       
        //generate random number for 1st -3rd, 4th-6th and 7th-10th 
        num1 = generator.nextInt(Integer.parseInt("9"));
        num2 = generator.nextInt(Integer.parseInt("9"));
        num3 = generator.nextInt(Integer.parseInt("9"));
        setTwo = generator.nextInt(Integer.parseInt("636")); 
        num7 = generator.nextInt(Integer.parseInt("9"));
        num8 = generator.nextInt(Integer.parseInt("9"));
        num9 = generator.nextInt(Integer.parseInt("9"));
        num10 = generator.nextInt(Integer.parseInt("9"));
        
        //integer to String for first 3 digits and last 4 digits
        setOne = Integer.toString(num1) + Integer.toString(num2) 
                  + Integer.toString(num3);
        setThree = Integer.toString(num7) + Integer.toString(num8) 
                  + Integer.toString(num9) + Integer.toString(num10);
        
        //to get 3 digit number for setTwo
        DecimalFormat fmt = new DecimalFormat("000");
        
        //print out the phone numbr
        System.out.println("============================================");
        System.out.print("Randomly selected Phon-number : ");
        System.out.println(setOne + "-" + fmt.format(setTwo) + "-" + setThree);
        System.out.println("============================================");
        System.out.println("Question one was called and ran sucessfully.");
    }
}
